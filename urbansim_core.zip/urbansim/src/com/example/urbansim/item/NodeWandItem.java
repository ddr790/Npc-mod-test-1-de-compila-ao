package com.example.urbansim.item;

import com.example.urbansim.network.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.phys.Vec3;

/**
 * Mode + selection live in the stack NBT ("mode": SIDEWALK/ROAD/CROSSWALK/REST_POINT/SPAWN_ZONE; "sel": node id).
 * Right-click = place a node, or snap to a nearby one, and link it to the selected node. Chain nodes quickly.
 * Cycle modes via keybind -> packet -> server writes NBT. All edits are server-side, then synced to clients.
 */
public class NodeWandItem extends Item {
    public NodeWandItem(Properties p) { super(p); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (!(ctx.getLevel() instanceof ServerLevel level)) return InteractionResult.SUCCESS;
        NodeNetwork net = NodeNetwork.get(level);
        var tag = ctx.getItemInHand().getOrCreateTag();
        Node.Type type = Node.Type.valueOf(tag.contains("mode") ? tag.getString("mode") : "SIDEWALK");
        Vec3 pos = ctx.getClickLocation().add(0, 0.01, 0);

        Node near = net.nearest(pos, type, 1.0);
        if (near == null) near = net.addNode(type, pos);

        int sel = tag.getInt("sel");
        if (sel > 0 && sel != near.id && net.node(sel) != null) {
            boolean twoWay = type != Node.Type.ROAD; // roads are one-way by default
            Node.Type kind = (type == Node.Type.REST_POINT || type == Node.Type.SPAWN_ZONE) ? Node.Type.SIDEWALK : type;
            net.link(sel, near.id, kind, twoWay);
        }
        tag.putInt("sel", near.id);
        // TODO: send delta packet to nearby clients
        return InteractionResult.CONSUME;
    }
}
