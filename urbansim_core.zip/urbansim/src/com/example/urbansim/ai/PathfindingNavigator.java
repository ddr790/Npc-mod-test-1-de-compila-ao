package com.example.urbansim.ai;

import com.example.urbansim.network.*;
import it.unimi.dsi.fastutil.ints.*;

import java.util.*;

/** A* over the node graph. Edge kinds are filtered per agent class. */
public final class PathfindingNavigator {
    public enum Agent {
        PEDESTRIAN(Set.of(Node.Type.SIDEWALK, Node.Type.CROSSWALK)),
        VEHICLE(Set.of(Node.Type.ROAD));
        final Set<Node.Type> allowed;
        Agent(Set<Node.Type> a) { allowed = a; }
    }

    private record Entry(int id, float f) {}

    /** Ordered edge list from -> to, or empty if unreachable. Budget expansions or run off-thread. */
    public static List<SplineEdge> findPath(NodeNetwork net, int from, int to, Agent agent, int maxExpansions) {
        Node goal = net.node(to);
        if (goal == null || net.node(from) == null) return List.of();

        PriorityQueue<Entry> open = new PriorityQueue<>(Comparator.comparingDouble(Entry::f));
        Int2FloatOpenHashMap g = new Int2FloatOpenHashMap();
        Int2ObjectOpenHashMap<SplineEdge> came = new Int2ObjectOpenHashMap<>();
        g.defaultReturnValue(Float.MAX_VALUE);
        g.put(from, 0f);
        open.add(new Entry(from, 0f));

        int expansions = 0;
        while (!open.isEmpty() && expansions++ < maxExpansions) {
            Entry cur = open.poll();
            if (cur.id() == to) return reconstruct(came, from, to);
            for (SplineEdge e : net.edgesFrom(cur.id())) {
                if (!agent.allowed.contains(e.kind)) continue;
                float cost = g.get(cur.id()) + e.length() + (e.kind == Node.Type.CROSSWALK ? 4f : 0f);
                if (cost < g.get(e.to)) {
                    g.put(e.to, cost);
                    came.put(e.to, e);
                    float h = (float) net.node(e.to).pos.distanceTo(goal.pos);
                    open.add(new Entry(e.to, cost + h));
                }
            }
        }
        return List.of();
    }

    private static List<SplineEdge> reconstruct(Int2ObjectOpenHashMap<SplineEdge> came, int from, int to) {
        LinkedList<SplineEdge> path = new LinkedList<>();
        for (int id = to; id != from; ) { SplineEdge e = came.get(id); path.addFirst(e); id = e.from; }
        return path;
    }
}
