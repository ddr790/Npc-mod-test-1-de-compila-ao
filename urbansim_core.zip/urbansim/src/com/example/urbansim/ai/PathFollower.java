package com.example.urbansim.ai;

import com.example.urbansim.network.SplineEdge;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Kinematic follower: moves along a list of splines at constant speed.
 * Vehicles: setPos(pos()) + setYRot(yaw()) each tick.
 * Pedestrians: feed pos() to MoveControl, or setPos with a ground snap.
 */
public final class PathFollower {
    private final List<SplineEdge> path;
    private int idx;
    private float dist;
    private Vec3 pos = Vec3.ZERO;
    private float yaw;

    public PathFollower(List<SplineEdge> path) { this.path = path; update(); }

    public boolean finished() { return idx >= path.size(); }
    public Vec3 pos() { return pos; }
    public float yaw() { return yaw; }

    /** @return false while waiting at a red light / crosswalk. */
    public boolean tick(float speedBlocksPerTick, long gameTime) {
        if (finished()) return false;
        if (dist == 0f && !TrafficController.canEnter(path.get(idx), gameTime)) return false; // hold at edge start
        dist += speedBlocksPerTick;
        while (dist >= path.get(idx).length()) {
            dist -= path.get(idx).length();
            if (++idx >= path.size()) return true;
            if (!TrafficController.canEnter(path.get(idx), gameTime)) { dist = 0f; update(); return false; }
        }
        update();
        return true;
    }

    private void update() {
        if (finished()) return;
        SplineEdge e = path.get(idx);
        float t = e.tAtDistance(dist);
        pos = e.point(t);
        Vec3 tan = e.tangent(t);
        float target = (float) (Mth.atan2(tan.z, tan.x) * Mth.RAD_TO_DEG) - 90f;
        yaw = Mth.rotLerp(0.3f, yaw, target); // smooth turning
    }
}
