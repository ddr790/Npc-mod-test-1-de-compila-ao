package com.example.urbansim.ai;

import com.example.urbansim.network.Node;
import com.example.urbansim.network.SplineEdge;

/** Stateless, game-time-derived signal phases: no per-light entities, nothing to sync. */
public final class TrafficController {
    public enum Light { GREEN, YELLOW, RED }
    private static final int CYCLE = 400; // group 0: green 0-160, yellow 160-200 | group 1 is offset by 200

    public static Light roadLight(int group, long gameTime) {
        int t = (int) (gameTime % CYCLE);
        int local = ((t - group * 200) % CYCLE + CYCLE) % CYCLE;
        if (local < 160) return Light.GREEN;
        if (local < 200) return Light.YELLOW;
        return Light.RED;
    }

    /** Can an agent enter this edge right now? */
    public static boolean canEnter(SplineEdge e, long gameTime) {
        if (e.signalGroup < 0) return true;
        Light l = roadLight(e.signalGroup, gameTime);
        if (e.kind == Node.Type.ROAD) return l != Light.RED;
        if (e.kind == Node.Type.CROSSWALK) return l == Light.RED; // walk when the crossed road is red
        return true;
    }
}
