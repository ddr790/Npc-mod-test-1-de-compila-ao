package com.example.urbansim.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

/** A graph vertex. Immutable id, mutable position. */
public final class Node {
    public enum Type { SIDEWALK, ROAD, CROSSWALK, REST_POINT, SPAWN_ZONE }

    public final int id;
    public final Type type;
    public Vec3 pos;
    /** Half-size, only used by SPAWN_ZONE (orange box). */
    public Vec3 extent = Vec3.ZERO;
    /** REST_POINT: 0 = stand/talk, 1 = sit. SPAWN_ZONE: max entities. */
    public int param;

    public Node(int id, Type type, Vec3 pos) {
        this.id = id; this.type = type; this.pos = pos;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("id", id); t.putString("type", type.name());
        t.putDouble("x", pos.x); t.putDouble("y", pos.y); t.putDouble("z", pos.z);
        t.putDouble("ex", extent.x); t.putDouble("ey", extent.y); t.putDouble("ez", extent.z);
        t.putInt("param", param);
        return t;
    }

    public static Node load(CompoundTag t) {
        Node n = new Node(t.getInt("id"), Type.valueOf(t.getString("type")),
                new Vec3(t.getDouble("x"), t.getDouble("y"), t.getDouble("z")));
        n.extent = new Vec3(t.getDouble("ex"), t.getDouble("ey"), t.getDouble("ez"));
        n.param = t.getInt("param");
        return n;
    }
}
