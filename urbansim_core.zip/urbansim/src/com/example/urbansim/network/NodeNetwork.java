package com.example.urbansim.network;

import it.unimi.dsi.fastutil.ints.*;
import it.unimi.dsi.fastutil.longs.*;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Per-dimension registry + adjacency + spatial hash. Server-authoritative, persisted as SavedData. */
public class NodeNetwork extends SavedData {
    private static final String NAME = "urbansim_network";
    private static final int CELL = 16; // spatial hash cell size (blocks)

    private final Int2ObjectMap<Node> nodes = new Int2ObjectOpenHashMap<>();
    private final Int2ObjectMap<List<SplineEdge>> out = new Int2ObjectOpenHashMap<>();
    private final Long2ObjectMap<IntList> grid = new Long2ObjectOpenHashMap<>();
    private int nextId = 1;
    /** Bumped on every edit; clients/renderers rebuild caches when it changes. */
    public int revision;

    public static NodeNetwork get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(NodeNetwork::load, NodeNetwork::new, NAME);
    }

    // ---- editing (used by the wand) ----
    public Node addNode(Node.Type type, Vec3 pos) {
        Node n = new Node(nextId++, type, pos);
        nodes.put(n.id, n);
        grid.computeIfAbsent(cell(pos), k -> new IntArrayList()).add(n.id);
        touch();
        return n;
    }

    public SplineEdge link(int a, int b, Node.Type kind, boolean bidirectional) {
        SplineEdge e = linkOne(a, b, kind);
        if (bidirectional) linkOne(b, a, kind);
        touch();
        return e;
    }

    private SplineEdge linkOne(int a, int b, Node.Type kind) {
        SplineEdge e = new SplineEdge(a, b, kind);
        e.rebuild(nodes.get(a).pos, nodes.get(b).pos);
        out.computeIfAbsent(a, k -> new ArrayList<>()).add(e);
        return e;
    }

    public void removeNode(int id) {
        Node n = nodes.remove(id);
        if (n == null) return;
        IntList l = grid.get(cell(n.pos));
        if (l != null) l.rem(id);
        out.remove(id);
        out.values().forEach(list -> list.removeIf(e -> e.to == id));
        touch();
    }

    public void moveNode(int id, Vec3 pos) {
        Node n = nodes.get(id);
        IntList l = grid.get(cell(n.pos)); if (l != null) l.rem(id);
        n.pos = pos;
        grid.computeIfAbsent(cell(pos), k -> new IntArrayList()).add(id);
        out.values().forEach(list -> list.forEach(e -> {
            if (e.from == id || e.to == id) { e.c1 = e.c2 = null; e.rebuild(nodes.get(e.from).pos, nodes.get(e.to).pos); }
        }));
        touch();
    }

    // ---- queries ----
    public Node node(int id) { return nodes.get(id); }
    public Collection<Node> allNodes() { return nodes.values(); }
    public List<SplineEdge> edgesFrom(int id) { return out.getOrDefault(id, List.of()); }
    public Iterable<List<SplineEdge>> allEdges() { return out.values(); }

    /** Nearest node of a given type within radius, via the spatial hash (only nearby cells are scanned). */
    public Node nearest(Vec3 p, Node.Type type, double radius) {
        int r = (int) Math.ceil(radius / CELL);
        int cx = (int) Math.floor(p.x / CELL), cz = (int) Math.floor(p.z / CELL);
        Node best = null; double bd = radius * radius;
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            IntList l = grid.get(key(cx + dx, cz + dz));
            if (l == null) continue;
            for (int id : l) {
                Node n = nodes.get(id);
                if (n.type != type) continue;
                double d = n.pos.distanceToSqr(p);
                if (d < bd) { bd = d; best = n; }
            }
        }
        return best;
    }

    private static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }
    private static long cell(Vec3 p) { return key((int) Math.floor(p.x / CELL), (int) Math.floor(p.z / CELL)); }

    private void touch() { revision++; setDirty(); }

    // ---- persistence ----
    @Override public CompoundTag save(CompoundTag root) {
        ListTag ns = new ListTag(), es = new ListTag();
        nodes.values().forEach(n -> ns.add(n.save()));
        out.values().forEach(l -> l.forEach(e -> es.add(e.save())));
        root.put("nodes", ns); root.put("edges", es); root.putInt("next", nextId);
        return root;
    }

    public static NodeNetwork load(CompoundTag root) {
        NodeNetwork net = new NodeNetwork();
        net.nextId = Math.max(1, root.getInt("next"));
        for (Tag t : root.getList("nodes", Tag.TAG_COMPOUND)) {
            Node n = Node.load((CompoundTag) t);
            net.nodes.put(n.id, n);
            net.grid.computeIfAbsent(cell(n.pos), k -> new IntArrayList()).add(n.id);
        }
        for (Tag t : root.getList("edges", Tag.TAG_COMPOUND)) {
            SplineEdge e = SplineEdge.load((CompoundTag) t);
            e.rebuild(net.nodes.get(e.from).pos, net.nodes.get(e.to).pos);
            net.out.computeIfAbsent(e.from, k -> new ArrayList<>()).add(e);
        }
        return net;
    }
}
