package com.example.urbansim.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

/** Directed cubic Bezier edge with an arc-length table for constant-speed travel. */
public final class SplineEdge {
    private static final int SAMPLES = 24;

    public final int from, to;
    public final Node.Type kind;      // SIDEWALK, ROAD or CROSSWALK
    public Vec3 c1, c2;               // control points (world space)
    /** -1 = unsignalled. Roads: signal group. Crosswalks: group of the road they cross. */
    public int signalGroup = -1;

    private transient Vec3 a, b;
    private transient float[] arc;            // cumulative length per sample
    private transient Vec3[] polyline;        // cached for the renderer

    public SplineEdge(int from, int to, Node.Type kind) {
        this.from = from; this.to = to; this.kind = kind;
    }

    /** Call after creation, load, or when either endpoint node moves. */
    public void rebuild(Vec3 start, Vec3 end) {
        a = start; b = end;
        if (c1 == null) { c1 = a.lerp(b, 1 / 3.0); c2 = a.lerp(b, 2 / 3.0); }
        polyline = new Vec3[SAMPLES + 1];
        arc = new float[SAMPLES + 1];
        for (int i = 0; i <= SAMPLES; i++) {
            polyline[i] = point(i / (float) SAMPLES);
            if (i > 0) arc[i] = arc[i - 1] + (float) polyline[i].distanceTo(polyline[i - 1]);
        }
    }

    public float length() { return arc[SAMPLES]; }
    public Vec3[] polyline() { return polyline; }

    public Vec3 point(float t) {
        float u = 1 - t;
        return a.scale(u * u * u).add(c1.scale(3 * u * u * t))
                .add(c2.scale(3 * u * t * t)).add(b.scale(t * t * t));
    }

    public Vec3 tangent(float t) {
        float u = 1 - t;
        return c1.subtract(a).scale(3 * u * u)
                .add(c2.subtract(c1).scale(6 * u * t))
                .add(b.subtract(c2).scale(3 * t * t)).normalize();
    }

    /** Map a travelled distance to curve parameter t using the arc-length table. */
    public float tAtDistance(float d) {
        if (d <= 0) return 0;
        if (d >= length()) return 1;
        int i = 1;
        while (arc[i] < d) i++;
        float seg = arc[i] - arc[i - 1];
        float f = seg <= 1e-6f ? 0 : (d - arc[i - 1]) / seg;
        return (i - 1 + f) / SAMPLES;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("from", from); t.putInt("to", to); t.putString("kind", kind.name());
        t.putInt("sig", signalGroup);
        t.putDouble("c1x", c1.x); t.putDouble("c1y", c1.y); t.putDouble("c1z", c1.z);
        t.putDouble("c2x", c2.x); t.putDouble("c2y", c2.y); t.putDouble("c2z", c2.z);
        return t;
    }

    public static SplineEdge load(CompoundTag t) {
        SplineEdge e = new SplineEdge(t.getInt("from"), t.getInt("to"), Node.Type.valueOf(t.getString("kind")));
        e.signalGroup = t.getInt("sig");
        e.c1 = new Vec3(t.getDouble("c1x"), t.getDouble("c1y"), t.getDouble("c1z"));
        e.c2 = new Vec3(t.getDouble("c2x"), t.getDouble("c2y"), t.getDouble("c2z"));
        return e;
    }
}
