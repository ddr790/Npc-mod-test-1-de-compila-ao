package com.example.urbansim.client;

import com.example.urbansim.item.NodeWandItem;
import com.example.urbansim.network.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.List;

/** Draws nodes, splines, direction arrows and zones. Only active while the wand is held. */
@Mod.EventBusSubscriber(modid = "urbansim", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class NodeDebugRenderer {
    /** Filled by a sync packet (full network on wand equip, deltas on edit). */
    public static NodeNetwork clientNet;
    private static final double MAX_DIST_SQ = 96 * 96;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent ev) {
        if (ev.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        if (clientNet == null || mc.player == null || !(mc.player.getMainHandItem().getItem() instanceof NodeWandItem)) return;

        PoseStack ps = ev.getPoseStack();
        Vec3 cam = ev.getCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buf.getBuffer(RenderType.lines());

        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z); // camera-relative: avoids float jitter far from origin

        for (Node n : clientNet.allNodes()) {
            if (n.pos.distanceToSqr(cam) > MAX_DIST_SQ) continue;
            switch (n.type) {
                case SIDEWALK, CROSSWALK, REST_POINT -> LevelRenderer.renderLineBox(ps, vc, box(n.pos, 0.2), 0.2f, 1f, 0.3f, 1f);
                case ROAD -> LevelRenderer.renderLineBox(ps, vc, box(n.pos, 0.15), 0.2f, 0.7f, 1f, 1f);
                case SPAWN_ZONE -> LevelRenderer.renderLineBox(ps, vc,
                        new AABB(n.pos.subtract(n.extent), n.pos.add(n.extent)), 1f, 0.55f, 0.1f, 1f);
            }
        }

        PoseStack.Pose pose = ps.last();
        for (List<SplineEdge> list : clientNet.allEdges()) for (SplineEdge e : list) {
            Vec3[] pl = e.polyline();
            if (pl[0].distanceToSqr(cam) > MAX_DIST_SQ) continue; // coarse per-edge cull
            boolean road = e.kind == Node.Type.ROAD;
            float r = 0.2f, g = road ? 0.7f : 1f, b = road ? 1f : 0.3f;
            for (int i = 0; i < pl.length - 1; i++) line(vc, pose, pl[i], pl[i + 1], r, g, b);
            int m = pl.length / 2; // direction arrow at the middle
            Vec3 d = pl[m + 1].subtract(pl[m]).normalize();
            Vec3 side = new Vec3(-d.z, 0, d.x).scale(0.25);
            Vec3 tip = pl[m].add(d.scale(0.3));
            line(vc, pose, tip, pl[m].add(side), r, g, b);
            line(vc, pose, tip, pl[m].subtract(side), r, g, b);
        }
        ps.popPose();
        buf.endBatch(RenderType.lines());
    }

    private static AABB box(Vec3 c, double h) { return new AABB(c.x - h, c.y, c.z - h, c.x + h, c.y + 2 * h, c.z + h); }

    private static void line(VertexConsumer vc, PoseStack.Pose p, Vec3 a, Vec3 b, float r, float g, float bl) {
        Matrix4f m = p.pose(); Matrix3f n = p.normal();
        Vec3 d = b.subtract(a).normalize();
        vc.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, 1f).normal(n, (float) d.x, (float) d.y, (float) d.z).endVertex();
        vc.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, 1f).normal(n, (float) d.x, (float) d.y, (float) d.z).endVertex();
    }
}
