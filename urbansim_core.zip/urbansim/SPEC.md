# UrbanSim: architecture notes (Forge 1.20.1, Mojang mappings)

## Layers
1. **NodeNetwork** (SavedData, per dimension): nodes, directed spline edges, 16-block spatial hash. Server-authoritative; clients get a mirrored copy for rendering only.
2. **PathfindingNavigator**: A* on the node graph, filtered per agent class (pedestrian = SIDEWALK + CROSSWALK, vehicle = ROAD). Budget with `maxExpansions` or run on a worker thread against a read-only snapshot. Cache routes between popular node pairs.
3. **PathFollower**: kinematic movement along Bezier splines using an arc-length table (constant speed, tangent-based yaw). No vanilla A* and no physics, so thousands of agents stay cheap.
4. **TrafficController**: signal phases derived from game time. No per-light state or sync. Crosswalks open when the crossed road group is red.
5. **Wand + Renderer**: wand edits server-side; client renderer draws only while the wand is held.

## Performance rules
- **LOD by distance to nearest player**: <48 blocks: full entity + animation; 48-128: tick every 4th tick; >128: "virtual" agent (just edge id + distance, no entity). Materialize an entity when a player comes close.
- **Spawn zones (orange)** cap the live population and respawn from the virtual pool; never spawn inside player view.
- **Stagger ticks**: `(entityId + gameTime) % N`. Budget path requests to a few per tick.
- **Ground snap**: raycast down only every few ticks; sidewalks are authored, so heights are stored on nodes.
- **Collision avoidance**: neighbour query via the same spatial hash; slow down or sidestep laterally (offset from the spline by a per-agent lane offset) instead of replanning.

## Citizen behaviour
Use a small state machine per citizen: `WALK -> (arrive at REST_POINT) -> SIT | CHAT | PHONE -> WALK`. REST_POINT `param` selects sit vs. stand. Group chat: a spawn zone assigns 2-4 citizens to face a shared centre.
Weather and time: on each citizen tick check `level.isRainingAt(pos)` and `level.getDayTime()`. Rain: equip an umbrella item in the offhand (client model render layer). Night: reduce the walker count, trigger "go home" paths.
Use a PlayerModel-based renderer (`HumanoidMobRenderer` with `PlayerModel`) and pick a skin from a texture pool by entity UUID hash.

## Vehicles
Entities with `noPhysics`, driven by `PathFollower`. Keep a gap to the leader found via the spatial hash on the same edge. Stop at red (`TrafficController.canEnter`). At intersections, pick the next edge randomly from `edgesFrom(node)`.

## Sync
Server -> client packets: full network on wand equip (chunked), then edge/node deltas keyed by `revision`. Entities use vanilla tracking.

## Still to do
Mod bootstrap/registration, entity + renderer classes, keybind/packets, node deletion mode, SimpleChannel registration. The renderer and wand are the starting points.
